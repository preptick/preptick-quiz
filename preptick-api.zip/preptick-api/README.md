# Preptick Quiz API

This is a Node.js Express API for the Preptick quiz app.

## How to run

```bash
npm install
npm start
